import { ActionFormData, MessageFormData } from "@minecraft/server-ui";
import { getRanks, getPlayerRank, setPlayerRank } from "./plugin/ranks/rank.js";
import { claimRankKit } from "./plugin/ranks/rank_kits.js"; 

export function openRankShop(player) {
    const ranks = getRanks();
    const playerRank = getPlayerRank(player);
    const money = player.getDynamicProperty("money") || 0; 

    const form = new ActionFormData()
        // §f§0§1 otomatis memanggil desain shop_ui.json
        .title("RANK SHOP") 
        // Teks ini otomatis masuk ke kotak Stats Panel
        .body(`§l§b${player.name}§r\n§7Rank: ${playerRank.prefix}\n§7Money: §a$${money}`);

    const sortedRanks = Object.entries(ranks).sort((a, b) => a[1].priority - b[1].priority);
    const btnMap = [];

    // TOMBOL ITEMS (Otomatis menyusun ke bawah di sisi kanan)
    sortedRanks.forEach(([id, data]) => {
        let icon = data.priority <= playerRank.priority ? "textures/Other/checked" : "textures/ui/lock"; 
        let text = data.priority <= playerRank.priority ? `${data.prefix} §r\n§a[OWNED]` : `${data.prefix} §r\n§e$${data.price}`;
        
        form.button(text, icon);
        btnMap.push({ id, data });
    });

    form.show(player).then(res => {
        if (res.canceled) return;
        
        const selected = btnMap[res.selection];
        handleBuy(player, selected.id, selected.data);
    });
}

function handleBuy(player, rankID, data) {
    const currentRank = getPlayerRank(player);
    const money = player.getDynamicProperty("money") || 0;

    if (currentRank.priority >= data.priority) {
        return player.sendMessage("§cKamu sudah memiliki rank ini atau yang lebih tinggi!");
    }

    if (money < data.price) {
        return player.sendMessage(`§cUang kamu tidak cukup! Butuh §e$${data.price}`);
    }

    new MessageFormData()
        .title("Konfirmasi Pembelian")
        .body(`Apakah kamu yakin ingin membeli rank ${data.prefix} §rseharga §e$${data.price}§r?`)
        .button1("§lBELI")
        .button2("BATAL")
        .show(player).then(res => {
            if (res.selection === 1) { 
                player.setDynamicProperty("money", money - data.price);
                setPlayerRank(player, rankID);
                player.sendMessage(`§aSukses! Sisa uang: $${money - data.price}`);
                player.runCommand(`playsound random.levelup @s`);
            }
        });
}

export function openRankKitMenu(player) {
    const ranks = getRanks();
    const playerRank = getPlayerRank(player);
    const money = player.getDynamicProperty("money") || 0;

    const form = new ActionFormData()
        .title("RANK KITS")
        .body(`§l§b${player.name}§r\n§7Rank: ${playerRank.prefix}\n§7Money: §a$${money}`);

    const sortedRanks = Object.entries(ranks).sort((a, b) => a[1].priority - b[1].priority);
    const btnMap = [];

    sortedRanks.forEach(([id, data]) => {
        let icon = playerRank.priority >= data.priority ? "textures/ui/gift_square" : "textures/ui/lock"; 
        let text = playerRank.priority >= data.priority ? `Kit ${data.prefix} §r\n§a[KLAIM]` : `Kit ${data.prefix} §r\n§c[TERKUNCI]`;

        form.button(text, icon);
        btnMap.push({ id, priority: data.priority });
    });

    form.show(player).then(res => {
        if (res.canceled) return;

        const selected = btnMap[res.selection];
        if (playerRank.priority >= selected.priority) {
            claimRankKit(player, selected.id);
        } else {
            player.sendMessage("§cRank kamu belum cukup untuk kit ini!");
        }
    });
}
