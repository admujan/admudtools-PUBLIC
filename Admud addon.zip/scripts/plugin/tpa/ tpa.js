export function openTpaMenu(player) {
    player.sendMessage("§e[MineKings] Fitur TPA masih dalam tahap perbaikan.");
}