import { world } from "@minecraft/server";
import { getPlayerRank } from "./rank.js";

export function claimRankKit(player, specificRankID = null) {
    const targetRankID = specificRankID || (player.getDynamicProperty("rankID") || "member");
    
    const cooldownKey = `kit_cd_${targetRankID}`;
    const lastClaim = player.getDynamicProperty(cooldownKey) || 0;
    const now = Date.now();
    
    if (now - lastClaim < 86400000) { 
        player.sendMessage(`§cKamu sudah claim kit ${targetRankID} hari ini!`);
        return;
    }

    if (targetRankID === "member") {
        player.runCommand("give @s apple 10");
    } else if (targetRankID === "vip") {
        player.runCommand("give @s diamond_sword 1");
    } else if (targetRankID === "admin") {
        player.runCommand("give @s bedrock 64");
    }

    player.setDynamicProperty(cooldownKey, now);
    player.sendMessage(`§aBerhasil klaim kit ${targetRankID}!`);
    player.runCommand("playsound random.levelup @s");
}