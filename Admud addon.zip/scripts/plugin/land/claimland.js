export function openClaimMenu(player) {
    player.sendMessage("§e[MineKings] Fitur Claim Land masih dalam tahap perbaikan.");
}