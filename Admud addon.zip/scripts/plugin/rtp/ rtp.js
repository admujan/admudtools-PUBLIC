export function openRtpMenu(player) {
    player.sendMessage("§e[MineKings] Fitur RTP masih dalam tahap perbaikan.");
}